package com.example.pizzeria;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class RegisterSreen extends AppCompatActivity {

    DataBase dataBase;

    private User newUser;
    private Direction newDir;
    EditText etNewUsername;
    EditText etNewPassword;
    EditText etNewName;
    EditText etNewSurname;
    EditText etNewPhone;
    EditText etNewStreet;
    EditText etNewTown;
    EditText etNewNumber;
    EditText etNewPostalCode;

    Button btnConfirm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_sreen);

        dataBase= new DataBase(this.getApplicationContext());

        etNewUsername=(EditText) findViewById(R.id.etNewUsername);
        etNewPassword=(EditText) findViewById(R.id.etNewPassword);
        etNewName=(EditText) findViewById(R.id.etNewName);
        etNewSurname=(EditText) findViewById(R.id.etNewSurname);
        etNewPhone=(EditText) findViewById(R.id.etNewPhone);
        etNewStreet=(EditText) findViewById(R.id.etNewStreet);
        etNewTown=(EditText) findViewById(R.id.etNewTown);
        etNewNumber=(EditText) findViewById(R.id.etNewNumber);
        etNewPostalCode=(EditText) findViewById(R.id.etNewPostalCode);

        btnConfirm= (Button) findViewById(R.id.btnNewConfim);
        btnConfirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                SQLiteDatabase db=dataBase.getWritableDatabase();
                Cursor cursor=db.rawQuery("SELECT username FROM USER WHERE username='"+etNewUsername.getText().toString().trim()+"'",null);
                if(cursor.moveToFirst()){

                    //Creamos la direccion
                    String street=etNewStreet.getText().toString();
                    String town=etNewTown.getText().toString();
                    int number=Integer.parseInt(etNewNumber.getText().toString());
                    int postalCode=Integer.parseInt(etNewPostalCode.getText().toString());
                    if (!street.isEmpty() && !town.isEmpty() && number!=0 && postalCode!=0)
                        newDir= new Direction(street,town,number,postalCode);
                    else
                        Toast.makeText(RegisterSreen.this, getString(R.string.CamposIncompletos), Toast.LENGTH_SHORT).show();

                }else{
                    Toast.makeText(RegisterSreen.this, getString(R.string.userExists), Toast.LENGTH_SHORT).show();
                }

            }
        });
    }

    public void back(View view) {
        finish();
    }
}