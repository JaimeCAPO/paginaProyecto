package com.example.pizzeria;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class PizzaDescScreen extends AppCompatActivity {

    private Pizza pizza;

    private ImageView imgPizza;

    private TextView tvPizza;
    private TextView tvDescription;

    private Button btnOrder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pizza_desc_screen);

        imgPizza=(ImageView) findViewById(R.id.imgPizza);
        tvPizza=(TextView) findViewById(R.id.pizzaName);
        tvDescription=(TextView) findViewById(R.id.tvPizzaDescription);
    }

    public void back(View view) {
        finish();
    }
}