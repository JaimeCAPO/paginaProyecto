package com.example.pizzeria;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private Button btnPizzas;
    private Button btnPedidos;

    //usuario de la sesión.
    private User usuarioIni;

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id=item.getItemId();
        if(R.id.itemLogin==id){
            //crear intent de login.
                if(usuarioIni!=null){
                    usuarioIni=null;
                }else{
                    //abrir login screen
                }

        }else if(R.id.itemProfile==id){
            //crear intent de perfil
            if (usuarioIni!=null){
                //abrir ProfileSreen.
            }else{
                Toast.makeText(this, getString(R.string.notLogged), Toast.LENGTH_SHORT).show();
            }
        }


        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnPizzas= (Button) findViewById(R.id.btnPizzas);
        btnPedidos= (Button) findViewById(R.id.btnPedido);

        btnPizzas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //abrir screen pizzas
                if(usuarioIni!=null){

                }else{
                    Toast.makeText(MainActivity.this, getString(R.string.notLogged), Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnPedidos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //mirar si estas loggeado o no y mandar mensaje
                if(usuarioIni!=null){
                    //abrir screen pedidos.
                }else{
                    Toast.makeText(MainActivity.this, getString(R.string.notLogged), Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    public User getUsuarioIni() {
        return usuarioIni;
    }

    public void setUsuarioIni(User usuarioIni) {
        this.usuarioIni = usuarioIni;
    }
}