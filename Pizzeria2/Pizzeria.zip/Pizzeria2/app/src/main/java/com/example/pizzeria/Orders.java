package com.example.pizzeria;

public class Orders {
    private static int idPedido=0;
    private User userPedido;
    private Pizza[] pizzas;
    private Drink[] bebidas;
    private String coment;
    private double price;

    private static int place=0;

    public Orders(User userPedido, Pizza[] pizzas, Drink[] bebidas, String coment) {
        this.idPedido=place;
        place++;
        this.userPedido = userPedido;
        this.pizzas = pizzas;
        this.bebidas = bebidas;
        this.coment = coment;

        double count=0.00;
        for(Pizza pizza:pizzas){
            count=count+pizza.getPrice();
        }
        for (Drink bebida:bebidas){
            count=count+bebida.getPrice();
        }
        this.price=count;
    }

    public static int getIdPedido() {
        return idPedido;
    }

    public static void setIdPedido(int idPedido) {
        Orders.idPedido = idPedido;
    }

    public User getUserPedido() {
        return userPedido;
    }

    public void setUserPedido(User userPedido) {
        this.userPedido = userPedido;
    }

    public Pizza[] getPizzas() {
        return pizzas;
    }

    public void setPizzas(Pizza[] pizzas) {
        this.pizzas = pizzas;
    }

    public Drink[] getBebidas() {
        return bebidas;
    }

    public void setBebidas(Drink[] bebidas) {
        this.bebidas = bebidas;
    }

    public String getComent() {
        return coment;
    }

    public void setComent(String coment) {
        this.coment = coment;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public static int getPlace() {
        return place;
    }

    public static void setPlace(int place) {
        Orders.place = place;
    }
}
