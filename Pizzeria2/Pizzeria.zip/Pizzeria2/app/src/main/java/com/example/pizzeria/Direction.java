package com.example.pizzeria;

public class Direction {
    private int id;
    private String street;
    private String town;
    private int number;
    private int postalCode;

    public Direction(String street, String town, int number, int postalCode) {
        this.street = street;
        this.town = town;
        this.number = number;
        this.postalCode= postalCode;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getStreet() {
        return street;
    }

    public void setStreet(String street) {
        this.street = street;
    }

    public String getTown() {
        return town;
    }

    public void setTown(String town) {
        this.town = town;
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }
}
