package com.example.pizzeria;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DataBase extends SQLiteOpenHelper {

    private final String nombreBD="PIZZERIA";

    private String sentenciaUsers="CREATE TABLE USER(" +
            "username INTEGER PRIMARY KEY," +
            "password VARCHAR(300) NOT NULL,"+
            "name VARCHAR(50)," +
            "surname VARCHAR(50)," +
            "direction INTEGER ," +
            "phone INTEGER," +
            "FOREIGN KEY (direction) REFERENCES DIRECTION (id)) ";

    private String sentenciaDirections="CREATE TABLE DIRECTION(" +
            "id INTEGER PRIMARY KEY AUTOINCREMENT," +
            "street VARCHAR(250)," +
            "town VARCHAR(100) NOT NULL," +
            "number INTEGER," +
            "postalCode INTEGER)";

    private String sentenciaPizza="CREATE TABLE PIZZA(" +
            "name VARCHAR(50) PRIMARY KEY," +
            "description VARCHAR(500) NOT NULL," +
            "price DOUBLE NOT NULL)";

    private String sentenciaDrink="CREATE TABLE DRINK(" +
            "name VARCHAR(50) PRIMARY KEY," +
            "price DOUBLE NOT NULL)";


    public DataBase(@Nullable Context context) {
        super(context, "PIZZERIA", null, 1);
        //constructor
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(sentenciaDirections);
        db.execSQL(sentenciaUsers);
        db.execSQL(sentenciaPizza);
        db.execSQL(sentenciaDrink);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS USER");
        db.execSQL("DROP TABLE IF EXISTS DIRECTION");
        onCreate(db);
    }
}
