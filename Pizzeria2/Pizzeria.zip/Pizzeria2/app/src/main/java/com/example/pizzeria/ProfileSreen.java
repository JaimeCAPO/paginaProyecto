package com.example.pizzeria;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class ProfileSreen extends AppCompatActivity {

    private ImageView imgUser;

    private TextView tvUsername;
    private TextView tvName;
    private TextView tvSurname;
    private TextView tvPhone;
    private TextView tvEmployee;
    private TextView tvStreet;
    private TextView tvTown;
    private TextView tvNumber;
    private TextView tvPostalCode;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_sreen);

        imgUser=(ImageView) findViewById(R.id.imgUser);

        tvUsername=(TextView) findViewById(R.id.tvCampUsername);
        tvName=(TextView) findViewById(R.id.tvCampName);
        tvSurname=(TextView) findViewById(R.id.tvCampSurname);
        tvPhone=(TextView) findViewById(R.id.tvCampPhone);
        tvEmployee=(TextView) findViewById(R.id.tvCampEmployee);
        tvStreet=(TextView) findViewById(R.id.tvCampStreet);
        tvTown=(TextView) findViewById(R.id.tvCampTown);
        tvNumber=(TextView) findViewById(R.id.tvCampNumber);
        tvPostalCode=(TextView) findViewById(R.id.tvCampPostalCode);
    }

    public void back(View view) {
        finish();
    }
}